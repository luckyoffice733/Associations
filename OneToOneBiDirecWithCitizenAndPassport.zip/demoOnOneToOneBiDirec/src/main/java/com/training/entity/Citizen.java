package com.training.entity;

import jakarta.persistence.CascadeType;
import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.OneToOne;
import jakarta.persistence.PrimaryKeyJoinColumn;
import jakarta.persistence.Table;

@Entity
@Table(name = "CITIZEN")
public class Citizen {

        @Id
        @GeneratedValue(strategy = GenerationType.AUTO)
        @Column(name = "CID")
        private int cid;

        @Column(name = "CNAME")
        private String cname; 
        
        @OneToOne(cascade = CascadeType.ALL)
        private Passport passport;
        
        

		public Citizen() {
			super();
			// TODO Auto-generated constructor stub
		}
		
		

		public Citizen(int cid, String cname, Passport passport) {
			super();
			this.cid = cid;
			this.cname = cname;
			this.passport = passport;
		}



		public int getCid() {
			return cid;
		}

		public void setCid(int cid) {
			this.cid = cid;
		}

		public String getCname() {
			return cname;
		}

		public void setCname(String cname) {
			this.cname = cname;
		}

		public Passport getPassport() {
			return passport;
		}

		public void setPassport(Passport passport) {
			this.passport = passport;
		}



		@Override
		public String toString() {
			return "Citizen [cid=" + cid + ", cname=" + cname + ", passport=" + passport + "]";
		}
        
        
}
