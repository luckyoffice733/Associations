package com.traininng;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;

import com.training.entity.Citizen;
import com.training.entity.Passport;
import com.training.utility.HBUtil;

public class App 
{
    public static void main( String[] args )
    {
      SessionFactory sfty= HBUtil.getSessionFactory(); 
      Session  con =sfty.openSession();
      Transaction tx= con.beginTransaction();
      
      Citizen c = new Citizen();
      c.setCname("Manu Manjunatha");
      
      Passport pt = new Passport();
      pt.setPnumber("123456");
      
  

      // ASSOCIATE CITIZEN WITH PASSPORT
         pt.setCitizen(c);
    
      // ASSOCIATE PASSPORT WITH CITIZEN
          c.setPassport(pt);
          
          con.persist(pt);
          tx.commit();
  // CITIZEN CAN ACCESS PASSPORT
     Citizen ct=   con.find(Citizen.class,1);
     System.out.println("Citizen id is "+ct.getCid());
     System.out.println("Cititzen name is : "+ct.getCname());
     System.out.println("Citizen passport number is : "+ct.getPassport().getPnumber());
          
    
      //BiDirectional

     // PASSPORT CAN ACCESS CITIZEN BECAUSE IT IS BIDIRECTIONAL
     Passport pt1=   con.find(Passport.class,1);
     System.out.println("Passport id is "+pt1.getPid());
     System.out.println("Passport number is : "+pt1.getPnumber());
     System.out.println("Citizen Name is  : "+pt1.getCitizen().getCname());
      
     
     
     
    con.close();
    }
}
