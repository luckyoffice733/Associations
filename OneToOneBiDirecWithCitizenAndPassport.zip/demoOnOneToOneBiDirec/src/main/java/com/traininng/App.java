package com.traininng;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;

import com.training.entity.Citizen;
import com.training.entity.Passport;
import com.training.utility.HBUtil;

public class App 
{
    public static void main( String[] args )
    {
      SessionFactory sfty= HBUtil.getSessionFactory(); 
      Session  con =sfty.openSession();
      Transaction tx= con.beginTransaction();
      
      
  

      // ASSOCIATE CITIZEN WITH PASSPORT
   
    
      // ASSOCIATE PASSPORT WITH CITIZEN
  

  // CITIZEN CAN ACCESS PASSPORT

    
      //BiDirectional

     // PASSPORT CAN ACCESS CITIZEN BECAUSE IT IS BIDIRECTIONAL

    con.close();
    }
}
