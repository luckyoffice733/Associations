package com.training;

import java.time.LocalDate;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;

import com.training.entity.Address;
import com.training.entity.Customer;

public class App 
{
    public static void main( String[] args )
    {
        Configuration cfg = new Configuration();
        cfg.configure();
        
         SessionFactory sfty= cfg.buildSessionFactory();
         Session session= sfty.openSession();
        Transaction tx=   session.beginTransaction();
        
        
        Address a1 = new Address(); 
        a1.setAddressId(100L);
        a1.setStreet("8 East Walnut Street");
        a1.setCity("Jacksonville");
        
       
        
        Address a2 = new Address(); 
        a2.setAddressId(101L);
        a2.setStreet("720 Rockland Road");
        a2.setCity("Las vegas");
        
       
        Address a3 = new Address(103L,"37 Marlborough Street","Gallup"); 
       
     
        
        Customer c1 = new Customer();
        c1.setCustomerId(1234);
        c1.setName("James");
        c1.setEmailId("James01@cg.com");
        String dob ="1980-03-21";
        LocalDate ld = LocalDate.parse(dob);
        c1.setDateOfBirth(ld);
        c1.setAddress(a1);
        
        session.persist(c1);
        
        Customer c2 = new Customer();
        c2.setCustomerId(1235);
        c2.setName("Willam");
        c2.setEmailId("Willam01@cg.com");
        String dob1 ="1979-06-03";
        LocalDate ld1 = LocalDate.parse(dob1);
        c2.setDateOfBirth(ld1);
        c2.setAddress(a2);
        
        session.persist(c2);
        
        Customer c3 = new Customer();
        c3.setCustomerId(1236);
        c3.setName("Antony");
        c3.setEmailId("Antony_04@cg.com");
        String dob2 ="1983-09-18";
        LocalDate ld2 = LocalDate.parse(dob2);
        c3.setDateOfBirth(ld2);
        c3.setAddress(a3);
        
        session.persist(c3);
        
        
        
        
         
        tx.commit(); 
         
        session.close();
    }
}
