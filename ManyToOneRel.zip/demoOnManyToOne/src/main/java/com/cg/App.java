package com.cg;

import java.time.LocalDate;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;

import com.cg.entity.Customer;
import com.cg.entity.Loan;

public class App 
{
    public static void main( String[] args )
    {
        Configuration cfg = new Configuration();
        cfg.configure();
       SessionFactory sty = cfg.buildSessionFactory();
       Session sion=  sty.openSession();
       Transaction  tx = sion.beginTransaction();
       
       Customer c1= new Customer();
       c1.setCustomerId(1001);
       c1.setName("steven");
       c1.setEmailId("steven@cg.com");
       
       LocalDate d = LocalDate.parse("1980-01-01");
       c1.setDateOfBirth(d);
      
        sion.persist(c1);//storeing customer obejct
        
      Loan l1 = new Loan();
      l1.setLoanId(2001);
      l1.setAmount(612345d);
      LocalDate issueDate = LocalDate.parse("2014-09-02");
      l1.setIssueDate(issueDate);
      l1.setStatus("open");
      l1.setCustomer(c1);
      
      sion.persist(l1);
      
      
      Loan l2 = new Loan();
      l2.setLoanId(2002);
      l2.setAmount(2289073d);
      LocalDate  closeDate = LocalDate.parse("2000-08-12");
      l2.setIssueDate(closeDate);
      l2.setStatus("closed");
      l2.setCustomer(c1);
      
      sion.persist(l2);
      
      Loan l3 = new Loan();
      l3.setLoanId(2003);
      l3.setAmount(109376289d);
      LocalDate  openDate = LocalDate.parse("2001-12-01");
      l3.setIssueDate(openDate);
      l3.setStatus("open");
      l3.setCustomer(c1);
      
      sion.persist(l3);
      
        
       tx.commit();
       
       sion.close();
       
       
       
        
    }
}
